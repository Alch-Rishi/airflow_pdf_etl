import re, os, logging
from datetime import datetime
import glob
import re

# import pandas as pd

# from bs4 import BeautifulSoup

from elasticsearch import Elasticsearch

import tika
tika.initVM()
from tika import parser


root_dir = 'data/'
index_name = 'test'

# es = Elasticsearch([{'host': 'localhost', 'port': 9200}])


# doc = {
#     'author': 'kimchy',
#     'text': 'Elasticsearch: cool. bonsai cool.',
#     'timestamp': datetime.now(),
# }


from collections import Counter
from itertools import chain


_id = 0

dict_list = []

for filepath in glob.iglob(root_dir + '**/*.*', recursive=True):
#     print(filepath)
    product_dict = {}
    parsed = parser.from_file(filepath)
    metadata = parsed['metadata']
#     dict_list.append(metadata)
    
    product_dict['index'] = _id

    quick_path = filepath.replace(root_dir, '/')
    product_dict['Product Type'] = quick_path.split('/')[1]

    if 'Author' in metadata:
        product_dict['Author'] = metadata['Author']
    else: 
        product_dict['Author'] = ''
        
    #     product_dict['Created-By'] = metadata['creator']

    if 'Content-Type' in metadata:
        product_dict['Content Type'] = metadata['Content-Type']
    else: 
        product_dict['Content-Type'] = ''
        
#     if 'Last-Save-Date' in metadata:
#         product_dict['Date Published'] = metadata['Last-Save-Date']
#     else: 
#         product_dict['Date Published'] = ''
    product_dict['Date Published'] = datetime.now()
        
    if 'title' in metadata:
        product_dict['Title'] = metadata['title']
    else: 
        product_dict['Title'] = ''
        
    product_dict['Text'] = str(re.sub(r'\n\n+', '\n\n', parsed['content']).strip())
#     print(metadata)
    
    
#     print(filename.split('/'))

#     print(filename.replace(root_dir, '/'))
    basename = os.path.basename(filepath)
    if '-ENG-' in basename:
        product_dict['Language'] = 'English'
        product_dict['langcode'] = 'en'
    if '-ARB-' in basename:
        product_dict['Language'] = 'Arabic'
        product_dict['langcode'] = 'ar'
        
#     print(basename)
    product_dict['Filename'] = os.path.splitext(basename)[0]
    product_dict['Filepath'] = 'TESTdrive/data' + quick_path
    
    _id += 1
        
#     print(product_dict)
    
    dict_list.append(product_dict)
    
#     print(product_dict)
    
#     print(parsed)


for doc in dict_list:
    print(doc)
    _id = doc['index']
    es.index(index=index_name, id=_id, body=doc)
    
    es.indices.refresh(index=index_name)
    


# res = es.search(index="test", body={"query": {"match_all": {}}})
# print("Got %d Hits:" % res['hits']['total']['value'])
# for hit in res['hits']['hits']:
#     print("none" % hit["_source"])
